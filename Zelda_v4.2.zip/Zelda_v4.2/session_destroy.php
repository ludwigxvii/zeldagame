<?php
session_start();
echo "Sessione Distrutta";
session_destroy();




?>